package com.pe.proyecto.interfaces;

import com.pe.proyecto.entity.Departamento;

public interface DepartamentoDAO extends GenericoDAO<Departamento>{

}
