package com.pe.proyecto.interfaces;

import com.pe.proyecto.entity.Provincia;

public interface ProvinciaDAO extends GenericoDAO<Provincia> {

}
