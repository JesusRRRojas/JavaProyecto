package com.pe.proyecto.interfaces;

import com.pe.proyecto.entity.Distrito;

public interface DistritoDAO extends GenericoDAO<Distrito> {

}
