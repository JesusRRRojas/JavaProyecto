package com.pe.proyecto.api.dto;

public record UserDTO(String user, String password) {

}
