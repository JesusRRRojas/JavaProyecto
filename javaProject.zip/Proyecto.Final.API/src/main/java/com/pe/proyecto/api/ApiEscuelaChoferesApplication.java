package com.pe.proyecto.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ApiEscuelaChoferesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiEscuelaChoferesApplication.class, args);
	}

	
	
}
