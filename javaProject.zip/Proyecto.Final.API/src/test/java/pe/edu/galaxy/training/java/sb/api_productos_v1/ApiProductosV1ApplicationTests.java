package pe.edu.galaxy.training.java.sb.api_productos_v1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProductosV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
